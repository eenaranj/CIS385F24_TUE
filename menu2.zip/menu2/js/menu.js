var menu = [
    { title: "Main", url: "index.html" },
    { title: "About", url: "about.html" },
    { title: "Contact", url: "contact.html" },
    { title: "Page 1", url: "page1.html" }
];

var menu_items = "";

for (var i = 0; i < menu.length; i++) {
    menu_items += `
        <li>
            <a href="${menu[i].url}">${menu[i].title}</a>
        </li>
    `;
}

document.getElementById("my_menu").innerHTML = menu_items;